export default {
  lang: 'عربي',
};
